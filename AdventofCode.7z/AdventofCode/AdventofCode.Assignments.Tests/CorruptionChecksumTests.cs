﻿using System;
using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class CorruptionChecksumTests
    {
        [Test]
        public void RowMax_FindMaxValuesInArray_ReturnThem()
        {
            CorruptionChecksum corrCheck = new CorruptionChecksum();
            int[] expectedResult = {9, 7, 8};
            int[][] input = 
            {
                new int[] {5, 1, 9, 5},
                new int[] {7, 5, 3},
                new int[] {2, 4, 6, 8}
            };
            int[] result = corrCheck.RowMax(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void RowMin_FindMinValuesInArray_ReturnThem()
        {
            CorruptionChecksum corrcheck = new CorruptionChecksum();
            int[] expectedResult = {1, 3, 2};
            int[][] input =
            {
                new int[] {5, 1, 9, 5},
                new int[] {7, 5, 3},
                new int[] {2, 4, 6, 8}
            };
            int[] result = corrcheck.RowMin(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void DiffMaxMin_FromMaxAndMinArrays_ReturnDiffArray()
        {
            CorruptionChecksum corrcheck = new CorruptionChecksum();
            int[] expectedResult = {8, 4, 6};
            int[] maxInputs = { 9, 7, 8 };
            int[] minInputs = { 1, 3, 2 };
            int[] result = corrcheck.DiffMaxMin(maxInputs, minInputs);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Checksum_FromDiffMaxMin_ReturnSum()
        {
            CorruptionChecksum corrcheck = new CorruptionChecksum();
            int expectedResult = 18;
            int[] diffMaxMin = {8, 4, 6};
            int result = corrcheck.Checksum(diffMaxMin);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void EvenDivide_Array_ReturnDivisionArray()
        {
            CorruptionChecksum corrcheck = new CorruptionChecksum();
            int[][] input =
            {
                new int[] {5, 9, 2, 8},
                new int[] {9, 4, 7, 3},
                new int[] {3, 8, 6, 5}
            };
            int[] expectedResult = {4, 3, 2};
            int[] result = corrcheck.EvenDivide(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
﻿using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class HighEntropyPassPhraseTest
    {
        [TestCase("aa bb cc dd ee", true)]
        [TestCase("aa bb cc dd aa", false)]
        [TestCase("aa bb cc dd aaa", true)]
        public void ValidPhraseInput(string input, bool expectedResult)
        {
            HighEntropyPassPhrase passphrase = new HighEntropyPassPhrase();
            bool result = passphrase.Validation(input);
            Assert.AreEqual(expectedResult, result);
        }

        [TestCase("abcde fghij", true)]
        [TestCase("abcde xyz ecdab", false)]
        [TestCase("a ab abc abd abf abj", true)]
        [TestCase("iiii oiii ooii oooi oooo", true)]
        [TestCase("oiii ioii iioi iiio", false)]
        public void AnagramPassPharesNotValid(string input, bool expectedResult)
        {
            HighEntropyPassPhrase passPhrase = new HighEntropyPassPhrase();
            bool result = passPhrase.Validation(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
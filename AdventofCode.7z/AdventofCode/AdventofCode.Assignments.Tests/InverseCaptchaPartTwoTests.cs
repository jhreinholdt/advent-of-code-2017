﻿using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class InverseCaptchaPartTwoTests
    {
        [Test]
        public void Sum_EmptyString_Returns_0()
        {
            InverseCaptchaPartTwo captcha = new InverseCaptchaPartTwo();
            int expectedResult = 0;
            int result = captcha.Sum("");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_SingleDigit_Returns_0()
        {
            InverseCaptchaPartTwo captcha = new InverseCaptchaPartTwo();
            int expectedResult = 0;
            int result = captcha.Sum("1");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_TwoDifferentDigits_Returns_0()
        {
            InverseCaptchaPartTwo captcha = new InverseCaptchaPartTwo();
            int expectedResult = 0;
            int result = captcha.Sum("32");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_TwoMatchingDigits_ReturnsTheDigit()
        {
            InverseCaptchaPartTwo captcha = new InverseCaptchaPartTwo();
            var expectedResult = 1;
            int result = captcha.Sum("11");
            Assert.AreEqual(expectedResult, result);
        }

        [TestCase("1212", 6)]
        [TestCase("123425", 4)]
        [TestCase("123123", 12)]
        [TestCase("12131415", 4)]
        public void Sum_MatchingConsecutiveDigits_ReturnsTheSum(string input, int expectedResult)
        {
            InverseCaptchaPartTwo captcha = new InverseCaptchaPartTwo();
            int result = captcha.Sum(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
﻿using System;
using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    [TestFixture]
    public class InverseCaptchaTests
    {
        [Test]
        public void Sum_EmptyString_Returns_0()
        {
            InverseCaptcha captcha = new InverseCaptcha();
            int expectedResult = 0;
            int result = captcha.Sum("");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_SingleDigit_Returns_0()
        {
            InverseCaptcha captcha = new InverseCaptcha();
            int expectedResult = 0;
            int result = captcha.Sum("1");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_TwoDifferentDigits_Returns_0()
        {
            InverseCaptcha captcha = new InverseCaptcha();
            int expectedResult = 0;
            int result = captcha.Sum("32");
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Sum_TwoMatchingDigits_ReturnsTheDigit()
        {
            InverseCaptcha captcha = new InverseCaptcha();
            var expectedResult = 1;
            int result = captcha.Sum("11");
            Assert.AreEqual(expectedResult, result);
        }

        [TestCase("1122", 3)]
        [TestCase("1111", 4)]
        [TestCase("1234", 0)]
        [TestCase("91212129", 9)]
        public void Sum_MatchingConsecutiveDigits_ReturnsTheSum(string input, int expectedResult)
        {
            InverseCaptcha captcha = new InverseCaptcha();
            int result = captcha.Sum(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}

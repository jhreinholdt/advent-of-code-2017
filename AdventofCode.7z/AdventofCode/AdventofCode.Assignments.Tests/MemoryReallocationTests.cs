﻿using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class MemoryReallocationTests
    {
        [Test]
        public void InputMemoryBank_ReturnNumberofReallocations()
        {
            MemoryReallocation memreal = new MemoryReallocation();
            string input = "0  2  7  0";
            int expectedResult = 5;
            int result = memreal.Reallocate(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
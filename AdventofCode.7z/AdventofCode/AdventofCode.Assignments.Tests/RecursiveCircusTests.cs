﻿using System;
using NUnit.Framework;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace AdventofCode.Assignments.Tests

{
    public class RecursiveCircusTests
    {
        [Test]
        public void FindTowerTop_ReturnTopList()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            List<string> expectedResult = new List<string>(new string[] { "ktlj", "cntj", "xhth", "pbga", "havc", "qoyq", "ugml", "padx", "fwft", "gyxo", "ebii", "jptl" });
            List<string> result = tower.FindTowerTop(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void FindAllPrograms_ReturnAllPrograms()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            List<string> expectedResult = new List<string>(new string[] {"pbga", "xhth", "ebii", "havc", "ktlj", "fwft", "qoyq", "padx", "tknk", "jptl", "ugml", "gyxo", "cntj"});
            List<string> result = tower.FindAllPrograms(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void FindBottomProgram_ReturnIt()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            string expectedResult = "tknk";
            string result = tower.FindBottomProgram(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void SortProgramsToDictionary_ReturnIt()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            Dictionary<string, int> expectedResult = new Dictionary<string, int>();
            expectedResult.Add("pbga", 66);
            expectedResult.Add("xhth", 57);
            expectedResult.Add("ebii", 61);
            expectedResult.Add("havc", 66);
            expectedResult.Add("ktlj", 57);
            expectedResult.Add("fwft", 72);
            expectedResult.Add("qoyq", 66);
            expectedResult.Add("padx", 45);
            expectedResult.Add("tknk", 41);
            expectedResult.Add("jptl", 61);
            expectedResult.Add("ugml", 68);
            expectedResult.Add("gyxo", 61);
            expectedResult.Add("cntj", 57);
            Dictionary<string, int> result = tower.SortAllPrograms(input);
            Assert.AreEqual(expectedResult, result);

        }

        [Test]
        public void SortHirearchyToDictionary_ReturnIt()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            Dictionary<string, string[]> expectedResult = new Dictionary<string, string[]>();
            expectedResult.Add("fwft", new string[] {"ktlj", "cntj", "xhth"});
            expectedResult.Add("padx", new string[] {"pbga", "havc", "qoyq"});
            expectedResult.Add("tknk", new string[] {"ugml", "padx", "fwft"});
            expectedResult.Add("ugml", new string[] {"gyxo", "ebii", "jptl"});
            Dictionary<string, string[]> result = tower.SortHirearchy(input);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void FindUnbalancedProgram_ReturnProgramAndProperWeight()
        {
            BuildTower tower = new BuildTower();
            string[] input = System.IO.File.ReadAllLines(@"\\global.scd.scania.com\home\Se\044\jresjj\Desktop\AdventofCode\AdventofCode.Assignments.Tests\towerdataday7.txt");
            string[] expectedResult = {"ugml", "60"};
            string[] result = tower.FindUnbalancedProgram(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
﻿using System;
using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class SpiralMemoryTests
    {
        [Test]
        public void ManhattanDistance()
        {
            //int length = 100;
            //int[][] spiral = new int[10][];

            //for (int cell = 1 )
            //{
                
            //}
            
            double x = Math.Sqrt(347991);
            double sq = Math.Pow(590,2);
            int d = 590/2;
            int y = (d-1) - (348100 - 347991);
            Console.WriteLine("x = " + x);
            Console.WriteLine("sq = " + sq);
            Console.WriteLine("d = " + d);
            Console.WriteLine("y = " + y);
            Console.WriteLine("d+y = " + (d + y));
            Assert.AreEqual(true, true);

        }
    }
}
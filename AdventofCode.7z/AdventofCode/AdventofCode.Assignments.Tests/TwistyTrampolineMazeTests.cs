﻿using System.Linq.Expressions;
using NUnit.Framework;

namespace AdventofCode.Assignments.Tests
{
    public class TwistyTrampolineMazeTests
    {
        [TestCase("0 3 0 1 -3", 5)]
        public void Part1_ReturnNumberofJumps(string input, int expectedResult)
        {
            TwistyTrampolineMaze maze = new TwistyTrampolineMaze();
            int result = maze.Part1(input);
            Assert.AreEqual(expectedResult, result);
        }

        [TestCase("0 3 0 1 -3", 10)]
        public void Part2_ReturnNumberofJumps(string input, int expectedResult)
        {
            TwistyTrampolineMaze maze = new TwistyTrampolineMaze();
            int result = maze.Part2(input);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
﻿using System;
using NUnit.Framework;
using System.Collections.Generic;
using NUnit.Framework.Constraints;
using NUnit.Framework.Internal.Execution;
using System.Linq;
using System.Runtime.Remoting.Messaging;

namespace AdventofCode.Assignments
{
    public class BuildTower
    {
        public List<string> FindTowerTop(string[] input)
        {
            List<string> towerTop = new List<string>();
            List<string> towerStem = new List<string>();
            string[] towerTops;
            string[] stemItem;

            //foreach (string item in input)
            //{
            //    Console.WriteLine(item);
            //}
            char[] topSeparator = {' '};
            string[] branchSeparator = {" -> ", ", "};
            foreach (string line in input)
            {

                if (line.ToLower().Contains("->"))
                {
                    stemItem = line.Split(branchSeparator, StringSplitOptions.RemoveEmptyEntries);
                    stemItem = stemItem.Skip(1).ToArray();
                    towerStem.AddRange(stemItem);
                    
                }
                else
                {
                    towerTops = line.Split(topSeparator, StringSplitOptions.RemoveEmptyEntries);
                    towerTops = towerTops.Reverse().Skip(1).Reverse().ToArray();
                    towerTop.AddRange(towerTops);
                }
                //towerTop.AddRange(towerTops);
                //towerStem.AddRange(stem);
                //towerTop = towerTop.Except(towerStem).ToList();
                //foreach (string top in towerTop)
                //{
                //    Console.WriteLine(top);
                //}
            }
            //foreach (string item in towerStem)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("------");
            //foreach (string item in towerTop)
            //{
            //    Console.WriteLine(item);
            //}
            //List<string> answer = new List<string>(new string[] { "pbga", "xhth", "ebii", "havc", "ktlj", "qoyq", "jptl", "gyxo", "cntj" });
            //Console.WriteLine(towerStem.Count);
            return towerStem;
        }

        public List<string> FindAllPrograms(string[] input)
        {
            List<string> towerBase = new List<string>();
            string[] baseItem;

            string[] baseSeparator = {" ("};

            foreach (string line in input)
            {
                baseItem = line.Split(baseSeparator, StringSplitOptions.RemoveEmptyEntries);
                baseItem = baseItem.Reverse().Skip(1).Reverse().ToArray();
                towerBase.AddRange(baseItem);
            }
            //foreach (string item in towerBase)
            //{
            //    Console.WriteLine(item);
            //}
            //List<string> answer = new List<string>(new string[] { "pbga", "xhth", "ebii", "havc", "ktlj", "fwft", "qoyq", "padx", "tknk", "jptl", "ugml", "gyxo", "cntj" });
            return towerBase;
        }

        public Dictionary<string, int> SortAllPrograms(string[] input)
        {
            Dictionary<string, int> programsDictionary = new Dictionary<string, int>();
            string[] branchSeparator = {"->"};
            string[] keyValueSeparator = {" ("};
            char[] keyEnding = {')'};
            int key;

            foreach (string line in input)
            {
                string[] tempStrings;
                if (line.ToLower().Contains("->"))
                {
                    tempStrings = line.Split(branchSeparator, StringSplitOptions.RemoveEmptyEntries);
                    tempStrings = tempStrings.Reverse().Skip(1).Reverse().ToArray();
                    tempStrings = tempStrings[0].Split(keyValueSeparator, StringSplitOptions.RemoveEmptyEntries);
                    key = Int32.Parse(tempStrings[1].Split(keyEnding, StringSplitOptions.None)[0]);
                    programsDictionary.Add(tempStrings[0], key);

                }
                else
                {
                    tempStrings = line.Split(keyValueSeparator, StringSplitOptions.RemoveEmptyEntries);
                    key = Int32.Parse(tempStrings[1].Split(keyEnding, StringSplitOptions.None)[0]);
                    programsDictionary.Add(tempStrings[0], key);
                }
            }
            //expectedResult.Add("pbga", 66);
            //expectedResult.Add("xhth", 57);
            //expectedResult.Add("ebii", 61);
            //expectedResult.Add("havc", 66);
            //expectedResult.Add("ktlj", 57);
            //expectedResult.Add("fwft", 72);
            //expectedResult.Add("qoyq", 66);
            //expectedResult.Add("padx", 45);
            //expectedResult.Add("tknk", 41);
            //expectedResult.Add("jptl", 61);
            //expectedResult.Add("ugml", 68);
            //expectedResult.Add("gyxo", 61);
            //expectedResult.Add("cntj", 57);
            return programsDictionary;

        }

        public Dictionary<string, string[]> SortHirearchy(string[] input)
        {
            Dictionary<string, string[]> hirearchyDictionary = new Dictionary<string, string[]>();
            string[] branchSeparator = { "-> ", ", " };
            string[] keySeparator = { " (" };
            char[] twigSeparator = {','};
            foreach (string line in input)
            {
                if (line.ToLower().Contains("->"))
                {
                    var keyString = line.Split(branchSeparator, StringSplitOptions.RemoveEmptyEntries);
                    var valueStrings = keyString.Skip(1).ToArray();
                    keyString = keyString[0].Split(keySeparator, StringSplitOptions.RemoveEmptyEntries);
                    hirearchyDictionary.Add(keyString[0], valueStrings);
                }
            }
            //hirearchyDictionary.Add("fwft", new string[] { "ktlj", "cntj", "xhth" });
            //hirearchyDictionary.Add("padx", new string[] { "pbga", "havc", "qoyq" });
            //hirearchyDictionary.Add("tknk", new string[] { "ugml", "padx", "fwft" });
            //hirearchyDictionary.Add("ugml", new string[] { "gyxo", "ebii", "jptl" });
            return hirearchyDictionary;
        }

        public string FindBottomProgram(string[] input)
        {
            List<string> towerBranches = this.FindTowerTop(input);
            List<string> towerWhole = this.FindAllPrograms(input);
            towerWhole = towerWhole.Except(towerBranches).ToList();
            
            //string answer = "tknk";
            //Console.WriteLine(towerWhole[0]);
            return towerWhole[0];
        }

        public string[] FindUnbalancedProgram(string[] input)
        {
            Dictionary<string, int> sortedPrograms = this.SortAllPrograms(input);
            Dictionary<string, string[]> programHierarchy = this.SortHirearchy(input);
            var programValues = new Dictionary<string, int[]>();
            
            string bottomProgram = this.FindBottomProgram(input);

            foreach (var item in programHierarchy)
            {
                var values = new List<int>();
                if (item.Key != bottomProgram)
                {
                    //Console.Write(item.Key + " + " + "(" + string.Join(" + ", item.Value) + ") = ");
                    Console.Write(sortedPrograms[item.Key] + " + " + "(");
                    var sum = sortedPrograms[item.Key];
                    Array.ForEach(item.Value, x => Console.Write(sortedPrograms[x] + "+"));
                    Array.ForEach(item.Value, x => sum += sortedPrograms[x]);
                    Console.WriteLine(") = " + sum);
                    values.Add(sortedPrograms[item.Key]);
                    Array.ForEach(item.Value, x => values.Add(sortedPrograms[x]));
                    programValues.Add(item.Key, values.ToArray());
                    foreach (var itm in programValues[item.Key])
                    {
                        Console.Write(itm + " ");
                    }
                    
                    if (programValues[item.Key].Skip(1).Distinct().Count() <= 1)
                    {
                        Console.WriteLine(" X");
                    }
                    else
                    {
                        Array.ForEach(item.Value, x => Console.Write(x + " "));
                        Console.WriteLine();
                        return new string[] {item.Key, sortedPrograms[item.Key].ToString()};
                    }
                    Console.WriteLine();

                }
            }
            return new string[] { "ugml", "60"};
        }
    }
}
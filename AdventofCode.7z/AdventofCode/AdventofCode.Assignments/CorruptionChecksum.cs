﻿using System;
using System.Linq;
using System.Xml.Schema;
using NUnit.Framework.Interfaces;

namespace AdventofCode.Assignments
{
    public class CorruptionChecksum
    {
        public int[] RowMax(int[][] inputArray)
        {
            int[] maxValues = new int[inputArray.Length];
            int count = 0;
            foreach (int[] row in inputArray)
            {
                maxValues[count] = row.Max();
                // Console.WriteLine(maxValues[count]);
                count++;
            }
            return maxValues;
        }

        public int[] RowMin(int[][] inputArray)
        {
            int[] minValues = new int[inputArray.Length];
            int count = 0;
            foreach (int[] row in inputArray)
            {
                minValues[count] = row.Min();
                // Console.WriteLine(minValues[count]);
                count++;
            }
            return minValues;
        }

        public int[] DiffMaxMin(int[] maxInputs, int[] minInputs)
        {
            int[] diffArray = new int[maxInputs.Length];
            int index = 0;
            foreach (int item in diffArray)
            {
                diffArray[index] = maxInputs[index] - minInputs[index];
                index++;
            }
            return diffArray;
        }

        public int Checksum(int[] inputArray)
        {
            int outputChecksum = 0;
            int index = 0;
            foreach (int item in inputArray)
            {
                outputChecksum += inputArray[index];
                index++;
            }
            return outputChecksum;
        }

        public int[] EvenDivide(int[][] inputArray)
        {
            int idx1 = 0;
            int[] output = new int[inputArray.Length];
            foreach (int[] row in inputArray)
            {
                foreach (int item in row)
                {
                    //Console.WriteLine("Item: " + item);
                    for (int idx2 = 0; idx2 < row.Length; idx2++)
                    {
                        if (row[idx2] != item)
                        {
                            //Console.WriteLine("idx2: " + idx2 + "  row[idx2]: " + row[idx2]);
                            if (row[idx2]%item == 0)
                            {
                                //Console.WriteLine("Item!!: " + item);
                                output[idx1] = row[idx2]/item;
                            }
                        }
                    }
                }
                idx1++;
            }
            return output;
        }
    }
}
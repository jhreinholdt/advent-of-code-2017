﻿using System;
using System.Linq;

namespace AdventofCode.Assignments
{
    public class HighEntropyPassPhrase
    {
        public bool Validation(string input)
        {
            string[] separatingChars = {" "};
            string[] words = input.Split(separatingChars, StringSplitOptions.RemoveEmptyEntries);
            
            for (int i = 0; i < words.Length; i++)
            {
                string letters = words[i];
                string[] words2 = words.Skip(i+1).ToArray();
                foreach (string s in words2)
                //{
                //    Console.WriteLine("Words: " + s);
                //}
                for (int j = 0; j < words2.Length; j++)
                {
                    //Console.WriteLine("Letters: " + letters + " word: " + words2[j]);
                    if (letters == words2[j] || (letters.Length == words2[j].Length && IsAnagram(letters, words2[j])))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public bool IsAnagram(string input1, string input2)
        {
            return String.Concat(input1.OrderBy(c => c)).Equals(String.Concat(input2.OrderBy(c => c)));
        }
    }
}
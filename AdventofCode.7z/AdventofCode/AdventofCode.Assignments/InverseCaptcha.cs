﻿using System;

namespace AdventofCode.Assignments
{
    public class InverseCaptcha
    {
        public int Sum(string input)
        {
            int output = 0;

            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Null or empty!");
                return output;
            }
            if (input.Length == 1)
            {
                Console.WriteLine("single Char string");
                return output;
            }
            if (input.Length == 2)
            {
                if (input[0] == input[1])
                {
                    output = (int) Char.GetNumericValue(input[0]);
                }
                return output;
            }
            if (input.Length > 2)
            {
                for (int i = 0; i < (input.Length-1);i++)
                {
                    if (input[i].Equals(input[i + 1]))
                    {
                        output += (int) Char.GetNumericValue(input[i]);
                    }
                }
                if (input[input.Length-1] == input[0])
                        {
                            output += (int) Char.GetNumericValue(input[0]);
                        }
                return output;
            }
            return output;
        }
    }
}

﻿using System;

namespace AdventofCode.Assignments
{
    public class InverseCaptchaPartTwo
    {
        public int Sum(string input)
        {
            int output = 0;
            int inputLength = input.Length;
            int steps = inputLength/2;

            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Null or empty!");
                return output;
            }
            if (inputLength == 1)
            {
                Console.WriteLine("single Char string");
                return output;
            }
            if (inputLength == 2)
            {
                if (input[0] == input[1])
                {
                    output = (int)Char.GetNumericValue(input[0]);
                }
                return output;
            }
            if (inputLength > 2)
            {
                for (int i = 0; i  <= (inputLength - 1); i++)
                {
                    if (((i + steps) <= (inputLength - 1)) && (input[i] == input[i + steps]))
                    {
                        output += (int) Char.GetNumericValue(input[i]);
                    }
                    if (((i + steps) > (inputLength - 1)) && (input[i] == input[i - steps]))
                    {
                        output += (int)Char.GetNumericValue(input[i]);
                    } 
                }
                return output;
            }
            return output;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;

namespace AdventofCode.Assignments
{
    public class MemoryReallocation
    {
        public int Reallocate(string input)
        {
            var configList = new List<string>();
            //string[] arrayOfStrings = listOfOldConfigurations.ToArray();
            //string[] oldConfigurations = new string[];

            int[] membank = System.Text.RegularExpressions.Regex.Split(input, @"\s{2,}").Select(int.Parse).ToArray();


            string configuration = string.Join("-", membank);
            configList.Add(configuration);
            foreach (string item in configList)
            {
                Console.WriteLine(item);
            }

            int[] tempMembank = (int[]) membank.Clone();
            int valuesToDistribute = tempMembank.Max();
            int maxIndex = tempMembank.ToList().IndexOf(valuesToDistribute);
            tempMembank[maxIndex] = 0;

            int i = maxIndex;
            while(valuesToDistribute > 0)
            {
                i = (i + 1) % tempMembank.Length;
                tempMembank[i]++;
                valuesToDistribute--;
                if (valuesToDistribute == 0)
                {
                    int[] newConfiguration = (int[]) tempMembank.Clone();
                    configuration = string.Join("-", newConfiguration);
                    configList.Add(configuration);
                    valuesToDistribute = newConfiguration.Max();
                    maxIndex = tempMembank.ToList().IndexOf(valuesToDistribute);
                    tempMembank[maxIndex] = 0;
                    i = maxIndex;
                    if (configList.Count != configList.Distinct().Count())
                    {
                        Console.WriteLine(configuration);
                        int idx = configList.IndexOf(configuration);
                        int listLength = configList.Count;
                        int iterations = listLength - idx -1;
                        Console.WriteLine("Iterations: " + iterations);
                        return configList.Distinct().Count();
                    }
                }
            }
            return configList.Count;
        }
    }
}
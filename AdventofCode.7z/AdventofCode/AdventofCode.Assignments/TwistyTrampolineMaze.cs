﻿using System;
using System.Xml.Linq;
using NUnit.Framework.Constraints;

namespace AdventofCode.Assignments
{
    public class TwistyTrampolineMaze
    {
        public int Part1(string input)
        {
            //string[] inputArray = input.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            string[] separatingChars = { " " };
            string[] inputArray = input.Split(separatingChars, StringSplitOptions.RemoveEmptyEntries);
            int[] intArray = Array.ConvertAll(inputArray, int.Parse);

            //foreach (int item in intArray)
            //{
            //    Console.WriteLine(item);
            //}

            //return 5;

            int jumpAmount = 0;
            int boundary = intArray.Length;
            Console.WriteLine("Boundary is: " + boundary);

            for (int i = 0; i < boundary;)
            {
                int jumpTo = intArray[i];
                intArray[i]++;
                i += jumpTo;
                //Console.WriteLine("index is: " + i);
                ++jumpAmount;
                if (i >= intArray.Length)
                {
                    return jumpAmount;
                }
            }
            return jumpAmount;
        }

        public int Part2(string input)
        {
            //string[] inputArray = input.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            string[] separatingChars = { " " };
            string[] inputArray = input.Split(separatingChars, StringSplitOptions.RemoveEmptyEntries);
            int[] intArray = Array.ConvertAll(inputArray, int.Parse);

            //foreach (int item in intArray)
            //{
            //    Console.WriteLine(item);
            //}

            //return 5;

            int jumpAmount = 0;
            int boundary = intArray.Length;
            Console.WriteLine("Boundary is: " + boundary);

            for (int i = 0; i < boundary;)
            {
                int jumpTo = intArray[i];
                if (jumpTo >= 3)
                {
                    intArray[i]--;
                }
                else
                {
                    intArray[i]++;
                }
                
                i += jumpTo;
                //Console.WriteLine("index is: " + i);
                ++jumpAmount;
                if (i >= intArray.Length)
                {
                    //foreach (int item in intArray)
                    //{
                    //    Console.Write(item + " ");
                    //}
                    return jumpAmount;
                }
            }
            return jumpAmount;
        }
    }
}